# AlgoritimosDeOrdenação
Repositório dedicado ao trabalho semestral da faculdade UNIP-Tatuapé na matéria Atividade Prática Supervisionada

## Sobre o projeto
> Uma aplicação em java com objetivo de escolher 3 algoritimos de ordenção para testa-los e mostrar qual é o mais rápido.
#### Algoritimos escolhidos:
+ QuickSort
+ InsertionSort
+ SelectionSort
